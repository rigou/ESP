#pragma once

#define CMD_STRING_SIZE 30
#define CMD_TOKENS_MAX (CMD_STRING_SIZE/3)

// any change made to this enum should be reflected in CMD_LETTERS and cmd_parse()
enum Command {
	CMD_NOP=-1,
	CMD_ADMIN,	// administrative commands
	CMD_FEATURE, // enable/disable features
	CMD_WAIT	// wait given number of seconds
};

const char CMD_LETTERS[]="AFW"; // same order as enumeration "Command"

// if you do not want to implement this rather long help string then set REPLY_MAXLEN=30 below
const char CMD_HELP[]="A00	print help\n"
	"A01	print program name and version\n"
	"A02	print hostname and uptime\n"
	"A03	print Runled status (0=disabled, 1=enabled)\n"
    "A04	print OTA status (0=disabled, 1=enabled)\n"
    "A99	reset\n"
	"F00	disable Runled\n"
	"F01	enable RunLed\n"
	"Wxx	wait xx seconds";

const unsigned int REPLY_MAXLEN=sizeof(CMD_HELP);
	
struct CmdToken {
	Command cmd_int;
	int val_int;
};

int cmd_Read(CmdToken *cmd_tokens);
int cmd_Exec(Command cmd_int, int value_int);

static int cmd_parse(const char *commands_str, struct CmdToken *cmd_tokens);
static char *cmd_get_string(char *buffer_str, Command cmd_int, int value_int);
