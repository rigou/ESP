/* NetServer.ino - a server application framework for ESP32 and ESP8266
 *  Send a command to the server: ./client/espcmd.sh esp00 A00
 *  
 *  OTA is optional, uncomment line "#define RGWIFI_OTA_ENABLED" in library rgWiFi.h to activate it
 *  Perform the OTA update with: OTAupload.sh NetServer 192.168.2.30
 *  
 *  Required libraries: rgNetworkCredentials, rgWiFi
 *  
   2022-04-11 added command A04 (OTA status)
*/
#include <rgNetworkCredentials.h>
#include <rgWiFi.h>
#include "common.h"
#include "gpios.h"
#include "command.h"
#include "network.h"

// application-global variables are all instantiated here and are refered to with the 'extern' keyword
Feature_struct Features; // structure defined in common.h
NetInfo NetInfo_struct; // structure defined in rgWiFi.h

/*
** MAIN
*/
void setup() {
	Serial.begin(115200);
	while (!Serial) ; // wait for serial port to connect
	delay(500);
	rgTrace(__func__);
	Serial.printf("\n\n%s %s\n", APP_NAME, APP_VERSION);
    Serial.printf("%s %s\n", NETSERVER_NAME, NETSERVER_VERSION);

	net_Setup();
	net_NetInfo();
	//rgwifi_Printinfo(NetInfo_struct);
    while (WiFi.status()!=WL_CONNECTED) {
	    Serial.printf("%s connecting to %s\n", NetInfo_struct.net_hostname, NetInfo_struct.net_ssid);
		rgwifi_Reconnect(NetInfo_struct);
	}
	Serial.print("WiFi connected, IP address ");
	Serial.print(WiFi.localIP());
	Serial.printf(", port %d\n", SERVER_PORT);
	Serial.printf("send A00 for help on commands\n");

#ifdef RGWIFI_OTA_ENABLED
	rgwifi_OtaSetup(NetInfo_struct.net_hostname, ESPOTA_PASSWORD_HASH);
#endif
	com_RunLed(LOW);
}

void loop() {
	rgTrace(__func__);
	if (WiFi.status()==WL_CONNECTED) {
		// read a command string from the network (non-blocking) and parse it
		CmdToken cmd_tokens[CMD_TOKENS_MAX];
		int ntokens_int=cmd_Read(cmd_tokens);
		if (ntokens_int>0) {
			// execute each command
			for (int idx_int=0; idx_int<ntokens_int; idx_int++) {
				Command cmd_int=cmd_tokens[idx_int].cmd_int;
				int value_int=cmd_tokens[idx_int].val_int;
				com_RunLed(HIGH);
				if (cmd_Exec(cmd_int, value_int)==0) {
					// wait 1 second after each successfull command
					rgwifi_OtaDelay(500);
					com_RunLed(LOW);
					rgwifi_OtaDelay(500);
				}
				else {
					// wait 1/10 second after each failed command
					rgwifi_OtaDelay(100);
					com_RunLed(LOW);
				}
			}
		}
		net_CloseClient();
		com_Heartbeat(2);
	}
	else
		rgwifi_Reconnect(NetInfo_struct);
}
