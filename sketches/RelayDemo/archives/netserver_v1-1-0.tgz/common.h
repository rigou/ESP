#pragma once

#define APP_VERSION "v1.1.0"
#define APP_NAME	"NetServer" // spaces not permitted

#define HOSTNAME_MAXLEN 30

// if USE_HW_DEVICE_ID is defined below then gpios DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO define the device id, see net_device_id()
// else the device id = 0 and DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO are ignored
//#define USE_HW_DEVICE_ID 1

// structure instantiated in NetServer.ino
struct Feature_struct {
	short Runled_enabled_int=1; // RUNLED flashes on command activity and on errors
};

char *get_uptime(char *buffer_str);
void heartbeat_run_led(int count_int);
void set_run_led(bool state_bool);
