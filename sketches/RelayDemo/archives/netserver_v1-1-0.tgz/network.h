#pragma once

#include <rgNetworkCredentials.h>

struct NetInfo {
	const char *net_hostname;
	IPAddress net_ip;
	IPAddress net_gateway;
	IPAddress net_subnet;
	const char *net_ssid;
	const char *net_password;
};

void net_setup();
int net_connect_loop();
int net_connect();
void net_close_client();
int net_receive(char *buffer_str, const int length_int);
void net_reply(char *reply_str);
