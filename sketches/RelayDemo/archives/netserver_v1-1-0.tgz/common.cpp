#include <rgOtaEsp32.h>
#include "common.h"
#include "gpios.h"

extern Feature_struct Features; // structure instantiated in NetServer.ino

// return uptime in given 11 characters buffer
char *get_uptime(char *buffer_str) {
	unsigned long now_lng=millis()/1000;
	int h_int=now_lng/3600;
	int m_int=(now_lng-(h_int*3600))/60;
	int s_int=now_lng-(h_int*3600)-(m_int*60);
	sprintf(buffer_str, "%02d:%02d:%02d", h_int, m_int, s_int);
	return buffer_str;
}

// provides a visual feedback of the loop() function
// does not use delay() to allow interruptions
// duration: count_int=1:1s, count_int=2:1.3s, count_int=3:1.6s ...
void heartbeat_run_led(int count_int) {
	static unsigned long Last_time=0;
	unsigned long now_lng=millis();
	for (byte idx_int=0; idx_int<count_int; idx_int++) {
		unsigned int pulse_len_int=0;
		
		set_run_led(HIGH);
		rgota_delay(50); // ms
		set_run_led(LOW);
		rgota_delay(450); // ms
	}
	rgota_delay(1000); // delay between each sequence of flashes
}

void set_run_led(bool state_bool) {
	static short Run_led_init_int=0;
	if (!Run_led_init_int) {
		pinMode(RUNLED_GPIO, OUTPUT);
		Run_led_init_int=1;
	}
	// turn led on if enabled, turn led off unconditionally
	if ((state_bool==HIGH && Features.Runled_enabled_int)||(state_bool==LOW)) {
#if RUNLED_INVERTED
		digitalWrite(RUNLED_GPIO, !state_bool);
#else
		digitalWrite(RUNLED_GPIO, state_bool);
#endif
	}
}

// return the LSB binary string representation of given integer value, with given number of bits, into given caller-allocated buffer
//char *binstr(char *buffer_str, int nbits_int, unsigned int num_int) {
//	unsigned int idx_int=0;
//	unsigned int mask_int=1;
//    while (idx_int < nbits_int) {
//    	buffer_str[idx_int]=(mask_int & num_int)?'1':'0';
//        mask_int<<=1;
//        idx_int++;
//    }
//	buffer_str[idx_int]='\0';
//    return buffer_str;
//}
