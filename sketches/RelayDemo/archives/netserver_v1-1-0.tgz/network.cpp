#include <WiFi.h>
#include <rgOtaEsp32.h>
#include "common.h"
#include "gpios.h"
#include "command.h"
#include "network.h"

/* Network definitions *******************************************************************/

static const unsigned int SERVER_PORT = 59000;
static WiFiServer Server_obj(SERVER_PORT);
static WiFiClient Client_obj;

/* Network implementation *******************************************************************/

// /home/rigou/.arduino15/packages/esp32/hardware/esp32/2.0.2/libraries/WiFi/src/WiFiServer.h
//typedef enum {
//    WL_NO_SHIELD        = 255,   // for compatibility with WiFi Shield library
//    WL_IDLE_STATUS      = 0,
//    WL_NO_SSID_AVAIL    = 1,
//    WL_SCAN_COMPLETED   = 2,
//    WL_CONNECTED        = 3,
//    WL_CONNECT_FAILED   = 4,
//    WL_CONNECTION_LOST  = 5,
//    WL_DISCONNECTED     = 6
//} wl_status_t;

extern char Hostname_str[HOSTNAME_MAXLEN+1];

NetInfo NetInfos[6];

void net_setup() {
	// clim0 (test)
	NetInfos[0].net_hostname="esp00";
	NetInfos[0].net_ip=IPAddress(192, 168, 2, 30);
	NetInfos[0].net_gateway=GATEWAY_NET2;
	NetInfos[0].net_subnet=SUBNET_NET2;
	NetInfos[0].net_ssid=SSID_NET2;
	NetInfos[0].net_password=PASSWD_NET2;

#ifdef USE_HW_DEVICE_ID
	// clim1 (bureau)
	NetInfos[1].net_hostname="esp01";
	NetInfos[1].net_ip=IPAddress(192, 168, 2, 31);
	NetInfos[1].net_gateway=GATEWAY_NET2;
	NetInfos[1].net_subnet=SUBNET_NET2;
	NetInfos[1].net_ssid=SSID_NET2;
	NetInfos[1].net_password=PASSWD_NET2;

	// clim2 (sejour)
	NetInfos[2].net_hostname="esp02";
	NetInfos[2].net_ip=IPAddress(192, 168, 1, 111);
	NetInfos[2].net_gateway=GATEWAY_NET1;
	NetInfos[2].net_subnet=SUBNET_NET1;
	NetInfos[2].net_ssid=SSID_NET1;
	NetInfos[2].net_password=PASSWD_NET1;

	// clim3 (chambre Parents)
	NetInfos[3].net_hostname="esp03";
	NetInfos[3].net_ip=IPAddress(192, 168, 2, 33);
	NetInfos[3].net_gateway=GATEWAY_NET2;
	NetInfos[3].net_subnet=SUBNET_NET2;
	NetInfos[3].net_ssid=SSID_NET2;
	NetInfos[3].net_password=PASSWD_NET2;

	// clim4 (chambre Alessandro)
	NetInfos[4].net_hostname="esp04";
	NetInfos[4].net_ip=IPAddress(192, 168, 2, 34);
	NetInfos[4].net_gateway=GATEWAY_NET2;
	NetInfos[4].net_subnet=SUBNET_NET2;
	NetInfos[4].net_ssid=SSID_NET2;
	NetInfos[4].net_password=PASSWD_NET2;

	// clim5 (chambre Massi)
	NetInfos[5].net_hostname="esp05";
	NetInfos[5].net_ip=IPAddress(192, 168, 2, 35);
	NetInfos[5].net_gateway=GATEWAY_NET2;
	NetInfos[5].net_subnet=SUBNET_NET2;
	NetInfos[5].net_ssid=SSID_NET2;
	NetInfos[5].net_password=PASSWD_NET2;

	// these 3 pins select the device identifier, see net_device_id()
	pinMode(DEVBIT0_GPIO, INPUT_PULLUP);
	pinMode(DEVBIT1_GPIO, INPUT_PULLUP);
	pinMode(DEVBIT2_GPIO, INPUT_PULLUP);
#endif
}

// gpios DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO define the device id
// LOW represents the bit value 1
// return value: a device id in the range [0-7]
#define READ_DEVBIT(x) (digitalRead(x)==LOW?1:0)
int net_device_id() {
#ifdef USE_HW_DEVICE_ID
	return (READ_DEVBIT(DEVBIT2_GPIO)*4)+(READ_DEVBIT(DEVBIT1_GPIO)*2)+READ_DEVBIT(DEVBIT0_GPIO);
#else
	return 0;
#endif
}

// (re)connect to WiFi
int net_connect_loop() {
	heartbeat_run_led(5); // about to connect
	set_run_led(HIGH); // lit while connecting
	int status_int=net_connect();
	set_run_led(LOW);
	if (status_int != WL_CONNECTED) {
		Serial.printf("WiFi connection error %d\n", status_int);
		// wait before next try
		for (int count_int=0; count_int<10; count_int++) {
			Serial.printf("waiting %d\n", count_int);
			heartbeat_run_led(status_int);
		}
	}
	if (status_int == WL_CONNECTED) {
		static bool Done_ota_setup_bool=false;
		if (!Done_ota_setup_bool) {
			rgota_setup(Hostname_str, ESPOTA_PASSWORD_HASH);
			Done_ota_setup_bool=true;
			Serial.printf("send A00 for help on commands\n");
		}
	}
	set_run_led(LOW);
    return WiFi.status();
}
		
int net_connect() {
	//Serial.printf("debug net_connect begin\n");
	unsigned int timeout_int=15000; // ms, must be multiple of 100
	int netinfo_idx_int=net_device_id();
	if (netinfo_idx_int < sizeof(NetInfos)/sizeof(NetInfo)) {
		strncpy(Hostname_str, NetInfos[netinfo_idx_int].net_hostname, HOSTNAME_MAXLEN);
		Serial.printf("%s connecting to %s with config %d\n", Hostname_str, NetInfos[netinfo_idx_int].net_ssid, netinfo_idx_int);
		WiFi.mode(WIFI_STA); // not required but good practice
		if (WiFi.config(NetInfos[netinfo_idx_int].net_ip, NetInfos[netinfo_idx_int].net_gateway, NetInfos[netinfo_idx_int].net_subnet)) {
		    WiFi.begin(NetInfos[netinfo_idx_int].net_ssid, NetInfos[netinfo_idx_int].net_password);
		    while (WiFi.status() != WL_CONNECTED && timeout_int) {
		    	delay(100);
		    	timeout_int-=100;
		    }
		}
	
		if (WiFi.status() == WL_CONNECTED) {
			Server_obj.begin();
			Serial.printf("%s online, IP %s, port %u\n", Hostname_str, WiFi.localIP().toString(), SERVER_PORT);
		}
		else 
			Serial.printf("WiFi connection error %d\n", WiFi.status());
	}
	else
		Serial.printf("device id %d out of range\n", netinfo_idx_int);

    return WiFi.status();
}

void net_close_client() {
	Client_obj.stop();
}

// read data sent by the client, if any (non blocking)
// if returned value > 0 then caller must call net_close_client() after processing the data
// return value: number of characters stored in the buffer, 0=no client connection available or client opened connection but sent no data
int net_receive(char *buffer_str, const int length_int) {
	Client_obj = Server_obj.available();
	int idx_int=0;
	buffer_str[0]='\0';
	if (Client_obj) {
		memset(buffer_str, 0, length_int);
		// wait for the data to become actually readable by Client_obj.read()
		// because sometimes Client_obj.read() returns -1 when called for the first time after boot
		rgota_delay(250);
		while (idx_int<length_int-1) {
			char c1=Client_obj.read(); // returns 255 (-1) if nothing is available
			if (c1 == '\n' || c1 == '\r') {
				if (idx_int==0)
					Serial.printf("DEBUG net_receive(): empty command\n");
				break;
			}
			else if (c1 == 255) {
				if ((idx_int+1)%3) {
					Serial.printf("DEBUG net_receive(): invalid command length=%d\n", idx_int+1);
					for (int char_idx_int=0; char_idx_int<=idx_int; char_idx_int++)
						Serial.printf("'%c'(%d) ", buffer_str[char_idx_int], buffer_str[char_idx_int]);
					Serial.printf("\n");
				}
				break;
			}
			else
				buffer_str[idx_int++]=c1;
		}
		Serial.printf("<%s\n", buffer_str);
	}
	if (idx_int==0)
		net_close_client(); // no data
	return idx_int;
}

void net_reply(char *reply_str) {
	Serial.printf(">%s\n", reply_str);
	Client_obj.write(reply_str, strlen(reply_str));
	Client_obj.write('\n');
}
