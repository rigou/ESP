#include <rgOtaEsp32.h>
#include "common.h"
#include "command.h"
#include "network.h"

extern Feature_struct Features;
extern char Hostname_str[HOSTNAME_MAXLEN+1];

/* Execute given command with given value
*  cmd_int: any of the CMD_* constants
*  see CMD_HELP for a list of all commands
*/
int cmd_exec(Command cmd_int, int value_int) {
	int retval_int=0; // success
	//Serial.printf("cmd_exec %d, value %d\n", cmd_int, value_int);
	char net_reply_str[REPLY_MAXLEN+1];
	char timestamp_str[11];
	const int RESET_DELAY=5; // seconds
	get_uptime(timestamp_str);
	switch (cmd_int) {
		case CMD_ADMIN: 
			// administrative command: A00=print version, A01=print uptime
			switch (value_int) {
				case 0:
					strncpy(net_reply_str, CMD_HELP, sizeof(net_reply_str));
					net_reply(net_reply_str);
					break;
				case 1:
					sprintf(net_reply_str, "%s %s", APP_NAME, APP_VERSION);
					net_reply(net_reply_str);
					break;
				case 2:
					sprintf(net_reply_str, "%s %s", Hostname_str, timestamp_str);
					net_reply(net_reply_str);
					break;
				case 3:
					sprintf(net_reply_str, "Runled %d", Features.Runled_enabled_int);
					net_reply(net_reply_str);
					break;
				case 99:
					sprintf(net_reply_str, "Reset in %d seconds", RESET_DELAY);
					net_reply(net_reply_str);
					net_close_client();
					delay(RESET_DELAY*1000);
					ESP.restart();
					break;

				default:
					strcpy(net_reply_str, "ERR 2 "); // invalid value
					cmd_get_string(net_reply_str+6, cmd_int, value_int);
					net_reply(net_reply_str);
					retval_int=1;
					break;
			}
			break;
		
		case CMD_FEATURE:
			switch (value_int) {
				case 0:
				case 1:
					Features.Runled_enabled_int=value_int;
					break;

				default:
					strcpy(net_reply_str, "ERR 2 "); // invalid value
					cmd_get_string(net_reply_str+6, cmd_int, value_int);
					net_reply(net_reply_str);
					retval_int=1;
					break;
			}
			if (retval_int==0) {
				strcpy(net_reply_str, "OK ");
				cmd_get_string(net_reply_str+3, cmd_int, value_int);
				net_reply(net_reply_str);
			}
			break;

		case CMD_WAIT:
			rgota_delay(value_int*1000);
			strcpy(net_reply_str, "OK ");
			cmd_get_string(net_reply_str+3, cmd_int, value_int);
			net_reply(net_reply_str);
			break;
	}

	//Serial.printf("cmd_exec() returns %d\n", retval_int);
	return retval_int;
}

// read a command string from network (non-blocking) and parse it into given array of CmdToken
// return value: number of tokens parsed, 0=nothing read from network, -1=invalid command
int cmd_read(CmdToken *cmd_tokens) {
	int retval_int=0;
	char buffer_str[CMD_STRING_SIZE+1];
	int cmd_length_int=0;
	// read command string from network (non blocking)
	cmd_length_int=net_receive(buffer_str, CMD_STRING_SIZE+1);
	if (cmd_length_int > 0) {
		// parse command(s) and value(s) contained in the command string
		for (int idx_int=0; idx_int<CMD_TOKENS_MAX; idx_int++) {
			cmd_tokens[idx_int].cmd_int=CMD_NOP;
			cmd_tokens[idx_int].val_int=0;
		}
		int ntokens_int=cmd_parse(buffer_str, cmd_tokens);
		if (ntokens_int>0) {
			retval_int=ntokens_int;
		}
		else {
			char net_reply_str[6+CMD_STRING_SIZE+1];
			strcpy(net_reply_str, "ERR 1 "); // parse error
			strcat(net_reply_str, buffer_str); 
			net_reply(net_reply_str);
			retval_int=-1;
		}
	}
	return retval_int;
}

/* A command string is a series of concatenated 3-chars tokens
	3-char token: Cnn	C=command letter (A,F,P,T,W) nn=2 digits value (00-99)
	Examples of command string:
		'P01W10T21': power on, wait 10s, temperature 21C
		'A00A01' : print program version and system uptime
	Test loop: watch -n 1 "echo 'T18' |nc clim1 59000"
	Only the first CMD_TOKENS_MAX will be returned, exceeding tokens will be silently ignored
	Return value: number of tokens parsed in cmd_tokens[] or 0 on error (invalid token letter)

	See cmd_exec() for a list of all commands
*/
int cmd_parse(const char *commands_str, struct CmdToken *cmd_tokens) {
	int error_int=0;
	int bufflen_int=strlen(commands_str);
	int count_int=0;
	if (bufflen_int>0 && bufflen_int % 3 == 0) {
		int offset_int=0;
		for (offset_int=0; offset_int<bufflen_int; offset_int+=3) {
			char token_str[4];
			memcpy(token_str, commands_str+offset_int, 3);
			token_str[3]='\0';

			// parse each token in CMD_LETTERS
			switch(token_str[0]) {
				case 'A':
					cmd_tokens[count_int].cmd_int=CMD_ADMIN;
					break;
				case 'F':
					cmd_tokens[count_int].cmd_int=CMD_FEATURE;
					break;

				default:
					error_int=1;
			}
			if (error_int==0)
				cmd_tokens[count_int++].val_int=atoi(token_str+1);
			else
				break;
		}
	}
	return (error_int==0?count_int:0);
}

// return the 3 chars command string corresponding to cmd_int and value_int
char *cmd_get_string(char *buffer_str, Command cmd_int, int value_int) {
	buffer_str[0]=CMD_LETTERS[cmd_int];
	sprintf(buffer_str+1, "%02d", value_int);
	buffer_str[3]='\0';
	return buffer_str;
}
