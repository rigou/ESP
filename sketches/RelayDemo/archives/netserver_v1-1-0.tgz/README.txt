tar czf archives/netserver_v1-1-0.tgz client $(ls *ino *cpp *h *txt)

