// NetServer.ino - a sample application
// OTA update: python3 ~/.arduino15/packages/esp32/hardware/esp32/2.0.2/tools/espota.py -i 192.168.2.30 -p 3232 -P 18266 -a OTA0314 -f $(ls /tmp/arduino_build_*/*.ino.bin)
// send a command: ./client/espcmd.sh esp00 A00
// 2022-03-29
// Sketch uses 698373 bytes (53%) of program storage space. Maximum is 1310720 bytes.
// Global variables use 41852 bytes (12%) of dynamic memory, leaving 285828 bytes for local variables. Maximum is 327680 bytes.

#include <WiFi.h>
#include <rgOtaEsp32.h>
#include "common.h"
#include "gpios.h"
#include "command.h"
#include "network.h"

// application-global variables are all instantiated here and are refered to with the 'extern' keyword
Feature_struct Features; // structure defined in common.h
char Hostname_str[HOSTNAME_MAXLEN+1];

/*
** MAIN
*/
void setup() {
	Serial.begin(115200);
	while (!Serial) ; // wait for serial port to connect
	delay(500);
	Serial.printf("\n\n%s %s\n", APP_NAME, APP_VERSION);
	
	set_run_led(LOW);
	net_setup();
}

void loop() {

	int wifi_status_int=WiFi.status();
	if (wifi_status_int==WL_CONNECTED) {
		// read a command string from the network (non-blocking) and parse it
		CmdToken cmd_tokens[CMD_TOKENS_MAX];
		int ntokens_int=cmd_read(cmd_tokens);
		if (ntokens_int>0) {
			// execute each command
			for (int idx_int=0; idx_int<ntokens_int; idx_int++) {
				Command cmd_int=cmd_tokens[idx_int].cmd_int;
				int value_int=cmd_tokens[idx_int].val_int;
				set_run_led(HIGH);
				if (cmd_exec(cmd_int, value_int)==0) {
					// wait 1 second after each successfull command
					rgota_delay(500);
					set_run_led(LOW);
					rgota_delay(500);
				}
				else {
					// wait 1/10 second after each failed command
					rgota_delay(100);
					set_run_led(LOW);
				}
			}
		}
		net_close_client();
		heartbeat_run_led(2);
		ArduinoOTA.handle();
	}
	else
		net_connect_loop();
}
