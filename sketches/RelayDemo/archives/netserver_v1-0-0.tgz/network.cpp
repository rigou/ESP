#include <WiFi.h>
#include "common.h"
#include "gpios.h"
#include "network.h"
#include <rgOtaEsp32.h>

/* Network definitions *******************************************************************/

const unsigned int SERVER_PORT = 59000;
static WiFiServer Server_obj(SERVER_PORT);
static WiFiClient Client_obj;

/* Network implementation *******************************************************************/

// /home/rigou/.arduino15/packages/esp32/hardware/esp32/2.0.2/libraries/WiFi/src/WiFiServer.h
//typedef enum {
//    WL_NO_SHIELD        = 255,   // for compatibility with WiFi Shield library
//    WL_IDLE_STATUS      = 0,
//    WL_NO_SSID_AVAIL    = 1,
//    WL_SCAN_COMPLETED   = 2,
//    WL_CONNECTED        = 3,
//    WL_CONNECT_FAILED   = 4,
//    WL_CONNECTION_LOST  = 5,
//    WL_DISCONNECTED     = 6
//} wl_status_t;

// this external copy of NetInfo.net_hostname is visible to main() for OTA setup
char Hostname_str[HOSTNAME_MAXLEN+1];

NetInfo NetInfos[6];

void net_setup() {
	// clim0 (test)
	NetInfos[0].net_hostname="clim0";
	NetInfos[0].net_ip=IPAddress(192, 168, 2, 30);
	NetInfos[0].net_gateway=GATEWAY_NET2;
	NetInfos[0].net_subnet=SUBNET_NET2;
	NetInfos[0].net_ssid=SSID_NET2;
	NetInfos[0].net_password=PASSWD_NET2;

#ifdef USE_HW_DEVICE_ID
	// clim1 (bureau)
	NetInfos[1].net_hostname="clim1";
	NetInfos[1].net_ip=IPAddress(192, 168, 2, 31);
	NetInfos[1].net_gateway=GATEWAY_NET2;
	NetInfos[1].net_subnet=SUBNET_NET2;
	NetInfos[1].net_ssid=SSID_NET2;
	NetInfos[1].net_password=PASSWD_NET2;

	// clim2 (sejour)
	NetInfos[2].net_hostname="clim2";
	NetInfos[2].net_ip=IPAddress(192, 168, 1, 111);
	NetInfos[2].net_gateway=GATEWAY_NET1;
	NetInfos[2].net_subnet=SUBNET_NET1;
	NetInfos[2].net_ssid=SSID_NET1;
	NetInfos[2].net_password=PASSWD_NET1;

	// clim3 (chambre Parents)
	NetInfos[3].net_hostname="clim3";
	NetInfos[3].net_ip=IPAddress(192, 168, 2, 33);
	NetInfos[3].net_gateway=GATEWAY_NET2;
	NetInfos[3].net_subnet=SUBNET_NET2;
	NetInfos[3].net_ssid=SSID_NET2;
	NetInfos[3].net_password=PASSWD_NET2;

	// clim4 (chambre Alessandro)
	NetInfos[4].net_hostname="clim4";
	NetInfos[4].net_ip=IPAddress(192, 168, 2, 34);
	NetInfos[4].net_gateway=GATEWAY_NET2;
	NetInfos[4].net_subnet=SUBNET_NET2;
	NetInfos[4].net_ssid=SSID_NET2;
	NetInfos[4].net_password=PASSWD_NET2;

	// clim5 (chambre Massi)
	NetInfos[5].net_hostname="clim5";
	NetInfos[5].net_ip=IPAddress(192, 168, 2, 35);
	NetInfos[5].net_gateway=GATEWAY_NET2;
	NetInfos[5].net_subnet=SUBNET_NET2;
	NetInfos[5].net_ssid=SSID_NET2;
	NetInfos[5].net_password=PASSWD_NET2;

	// these 3 pins select the device identifier, see net_device_id()
	pinMode(DEVBIT0_GPIO, INPUT_PULLUP);
	pinMode(DEVBIT1_GPIO, INPUT_PULLUP);
	pinMode(DEVBIT2_GPIO, INPUT_PULLUP);
#endif
}

// gpios DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO define the device id
// LOW represents the bit value 1
// return value: a device id in the range [0-7]
#define READ_DEVBIT(x) (digitalRead(x)==LOW?1:0)
int net_device_id() {
#ifdef USE_HW_DEVICE_ID
	return (READ_DEVBIT(DEVBIT2_GPIO)*4)+(READ_DEVBIT(DEVBIT1_GPIO)*2)+READ_DEVBIT(DEVBIT0_GPIO);
#else
	return 0;
#endif
}

int net_connect() {
	//Serial.printf("debug net_connect begin\n");
	unsigned int timeout_int=15000; // ms, must be multiple of 100
	int netinfo_idx_int=net_device_id();
	if (netinfo_idx_int < sizeof(NetInfos)/sizeof(NetInfo)) {
		strncpy(Hostname_str, NetInfos[netinfo_idx_int].net_hostname, HOSTNAME_MAXLEN);
		Serial.printf("%s connecting to %s with config %d\n", Hostname_str, NetInfos[netinfo_idx_int].net_ssid, netinfo_idx_int);
		WiFi.mode(WIFI_STA); // not required but good practice
		if (WiFi.config(NetInfos[netinfo_idx_int].net_ip, NetInfos[netinfo_idx_int].net_gateway, NetInfos[netinfo_idx_int].net_subnet)) {
		    WiFi.begin(NetInfos[netinfo_idx_int].net_ssid, NetInfos[netinfo_idx_int].net_password);
		    while (WiFi.status() != WL_CONNECTED && timeout_int) {
		    	delay(100);
		    	timeout_int-=100;
		    }
		}
	
		if (WiFi.status() == WL_CONNECTED) {
			Server_obj.begin();
			Serial.printf("%s online, IP %s, port %u\n", Hostname_str, WiFi.localIP().toString(), SERVER_PORT);
		}
		else 
			Serial.printf("WiFi connection error %d\n", WiFi.status());
	}
	else
		Serial.printf("device id %d out of range\n", netinfo_idx_int);

    return WiFi.status();
}

void net_close() {
	Client_obj.stop();
}

// read data sent by the client, if any (non blocking)
// if returned value > 0 then caller must call net_close() after processing the data
// return value: number of characters stored in the buffer, 0=no client connection available or client opened connection but sent no data
int net_receive(char *buffer_str, const int length_int) {
	Client_obj = Server_obj.available();
	int idx_int=0;
	buffer_str[0]='\0';
	if (Client_obj) {
		memset(buffer_str, 0, length_int);
		// wait for the data to become actually readable by Client_obj.read()
		// because sometimes Client_obj.read() returns -1 when called for the first time after boot
		rgota_delay(250);
		while (idx_int<length_int-1) {
			char c1=Client_obj.read(); // returns 255 (-1) if nothing is available
			if (c1 == '\n' || c1 == '\r') {
				if (idx_int==0)
					Serial.printf("DEBUG net_receive(): empty command\n");
				break;
			}
			else if (c1 == 255) {
				if ((idx_int+1)%3) {
					Serial.printf("DEBUG net_receive(): invalid command length=%d\n", idx_int+1);
					for (int char_idx_int=0; char_idx_int<=idx_int; char_idx_int++)
						Serial.printf("'%c'(%d) ", buffer_str[char_idx_int], buffer_str[char_idx_int]);
					Serial.printf("\n");
				}
				break;
			}
			else
				buffer_str[idx_int++]=c1;
		}
		Serial.printf("<%s\n", buffer_str);
	}
	if (idx_int==0)
		net_close(); // no data
	return idx_int;
}

void net_reply(char *reply_str) {
	Serial.printf(">%s\n", reply_str);
	Client_obj.write(reply_str, strlen(reply_str));
	Client_obj.write('\n');
}

/* Input commands implementation *******************************************************************/


/* A command string is a series of concatenated 3-chars tokens
	3-char token: Cnn	C=command letter (A,F,P,T,W) nn=2 digits value (00-99)
	Examples of command string:
		'P01W10T21': power on, wait 10s, temperature 21C
		'A00A01' : print program version and system uptime
	Test loop: watch -n 1 "echo 'T18' |nc clim1 59000"
	Only the first CMD_TOKENS_MAX will be returned, exceeding tokens will be silently ignored
	Return value: number of tokens parsed in cmd_tokens[] or 0 on error (invalid token letter)

	See exec_command() for a list of all commands
*/
int parse_tokens(const char *commands_str, struct CmdToken *cmd_tokens) {
	int error_int=0;
	int bufflen_int=strlen(commands_str);
	int count_int=0;
	if (bufflen_int>0 && bufflen_int % 3 == 0) {
		int offset_int=0;
		for (offset_int=0; offset_int<bufflen_int; offset_int+=3) {
			char token_str[4];
			memcpy(token_str, commands_str+offset_int, 3);
			token_str[3]='\0';

			// parse each token in CMD_LETTERS
			switch(token_str[0]) {
				case 'A':
					cmd_tokens[count_int].cmd_int=CMD_ADMIN;
					break;
				case 'F':
					cmd_tokens[count_int].cmd_int=CMD_FEATURE;
					break;

				default:
					error_int=1;
			}
			if (error_int==0)
				cmd_tokens[count_int++].val_int=atoi(token_str+1);
			else
				break;
		}
	}
	return (error_int==0?count_int:0);
}
