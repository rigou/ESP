/* common.h - include this file first (ie before any other local header files)
 */

#ifndef common_h
#define common_h

#include <Arduino.h>

// if USE_HW_DEVICE_ID is defined below then gpios DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO define the device id, see net_device_id()
// else the device id = 0 and DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO are ignored
//#define USE_HW_DEVICE_ID 1

typedef struct Feature {
	short Runled_enabled_int=1; // RUNLED flashes on command activity and on errors
};

// any change made to this enum should be reflected in CMD_LETTERS and parse_tokens()
enum Command {
	CMD_NOP=-1,
	CMD_ADMIN,	// administrative commands
	CMD_FEATURE, // enable/disable features
	CMD_WAIT	// wait given number of seconds
};

const char CMD_LETTERS[]="AFW"; // same order as enumeration "Command"

char *binstr(char *buffer_str, int nbits_int, unsigned int num_int);
char *get_uptime(char *buffer_str);

void set_run_led(bool state_bool);
void heartbeat_run_led(int count_int);

#endif
