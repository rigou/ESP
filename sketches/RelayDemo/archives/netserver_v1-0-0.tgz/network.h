#ifndef network_h
#define network_h

#include <rgNetworkCredentials.h>

#define CMD_STRING_SIZE 30
#define CMD_TOKENS_MAX (CMD_STRING_SIZE/3)
#define HOSTNAME_MAXLEN 30

struct CmdToken {
	Command cmd_int;
	int val_int;
};

struct NetInfo {
	const char *net_hostname;
	IPAddress net_ip;
	IPAddress net_gateway;
	IPAddress net_subnet;
	const char *net_ssid;
	const char *net_password;
};

void net_setup();
int net_connect();
void net_close();
int net_receive(char *buffer_str, const int length_int);
void net_reply(char *reply_str);
int parse_tokens(const char *buffer_str, struct CmdToken *cmd_tokens);
#endif
