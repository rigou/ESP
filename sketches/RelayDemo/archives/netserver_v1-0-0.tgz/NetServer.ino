/* NetServer.ino - a sample application
 *  2022-03-26
 */

#define APP_VERSION "v1.0.0"
#define APP_NAME	"NetServer" // spaces not permitted

#include <WiFi.h>
#include <rgOtaEsp32.h>
#include "common.h"
#include "gpios.h"
#include "network.h"

Feature Features; // structure defined in common.h
extern char *Hostname_str; // string instantiated in network.cpp

/*
** MAIN
*/
void setup() {
	Serial.begin(115200);
	while (!Serial) ; // wait for serial port to connect
	delay(500);
	Serial.printf("\n\n%s %s\n", APP_NAME, APP_VERSION);
	
	set_run_led(LOW);
	net_setup();
}

void loop() {
ArduinoOTA.handle();
	int wifi_status_int;
	wifi_status_int=WiFi.status();
	if (wifi_status_int==WL_CONNECTED) {
		int idx_int=0;
		char buffer_str[CMD_STRING_SIZE+1];
		int cmd_length_int=0;
		// read command string from network (non blocking)
		cmd_length_int=net_receive(buffer_str, CMD_STRING_SIZE+1);
		if (cmd_length_int > 0) {
			// parse command(s) and value(s) contained in the command string
			struct CmdToken cmd_tokens[CMD_TOKENS_MAX];
			for (idx_int=0; idx_int<CMD_TOKENS_MAX; idx_int++) {
				cmd_tokens[idx_int].cmd_int=CMD_NOP;
				cmd_tokens[idx_int].val_int=0;
			}
			int ntokens_int=parse_tokens(buffer_str, cmd_tokens);
			if (ntokens_int>0) {
				// execute each command
				for (idx_int=0; idx_int<ntokens_int; idx_int++) {
					Command cmd_int=cmd_tokens[idx_int].cmd_int;
					int value_int=cmd_tokens[idx_int].val_int;
					set_run_led(HIGH);
					if (exec_command(cmd_int, value_int)==0) {
						// wait 1 second after each successfull command
						rgota_delay(500);
						set_run_led(LOW);
						rgota_delay(500);
					}
					else {
						// wait 1/10 second after each failed command
						rgota_delay(100);
						set_run_led(LOW);
					}
				}
			}
			else {
				char net_reply_str[6+CMD_STRING_SIZE+1];
				strcpy(net_reply_str, "ERR 1 "); // parse error
				strcat(net_reply_str, buffer_str); 
				net_reply(net_reply_str);
			}			
			net_close();
		}
		heartbeat_run_led(2);
	}
	else { 
		heartbeat_run_led(5); // about to connect
		set_run_led(HIGH); // lit while connecting
		int status_int=net_connect();
		set_run_led(LOW);
		if (status_int != WL_CONNECTED) {
			Serial.printf("WiFi connection error %d\n", status_int);
			// wait before next try
			for (int count_int=0; count_int<10; count_int++) {
				Serial.printf("waiting %d\n", count_int);
				heartbeat_run_led(status_int);
			}
		}
		if (status_int == WL_CONNECTED) {
			static bool Done_ota_setup_bool=false;
			if (!Done_ota_setup_bool) {
				rgota_setup(Hostname_str, ESPOTA_PASSWORD_HASH);
				Done_ota_setup_bool=true;
			}
		}
		
		set_run_led(LOW);
	}
}

/*
** COMMAND
*/

/* Execute given command with given value
*  cmd_int: any of the CMD_* constants
*  
* List of all commands:
* 	A00	print program name and version
* 	A01	print uptime
* 	A02	print current Runled status (0=disabled, 1=enabled)
* 	A99 reset
* 	
* 	F00 disable Runled
* 	F01 enable RunLed
*
*	Wxx	wait xx seconds
*/
int exec_command(Command cmd_int, int value_int) {
	int retval_int=0; // success
	//Serial.printf("exec_command %d, value %d\n", cmd_int, value_int);
	char net_reply_str[30];
	char timestamp_str[11];
	const int RESET_DELAY=5; // seconds
	get_uptime(timestamp_str);
	switch (cmd_int) {
		case CMD_ADMIN: 
			// administrative command: A00=print version, A01=print uptime
			switch (value_int) {
				case 0:
					sprintf(net_reply_str, "%s %s", APP_NAME, APP_VERSION);
					net_reply(net_reply_str);
					break;
				case 1:
					sprintf(net_reply_str, "Uptime %s", timestamp_str);
					net_reply(net_reply_str);
					break;
				case 2:
					sprintf(net_reply_str, "Runled %d", Features.Runled_enabled_int);
					net_reply(net_reply_str);
					break;
				case 99:
					sprintf(net_reply_str, "Reset in %d seconds", RESET_DELAY);
					net_reply(net_reply_str);
					net_close();
					delay(RESET_DELAY*1000);
					ESP.restart();
					break;

				default:
					strcpy(net_reply_str, "ERR 2 "); // invalid value
					get_cmd_string(net_reply_str+6, cmd_int, value_int);
					net_reply(net_reply_str);
					retval_int=1;
					break;
			}
			break;
		
		case CMD_FEATURE:
			switch (value_int) {
				case 0:
				case 1:
					Features.Runled_enabled_int=value_int;
					break;

				default:
					strcpy(net_reply_str, "ERR 2 "); // invalid value
					get_cmd_string(net_reply_str+6, cmd_int, value_int);
					net_reply(net_reply_str);
					retval_int=1;
					break;
			}
			if (retval_int==0) {
				strcpy(net_reply_str, "OK ");
				get_cmd_string(net_reply_str+3, cmd_int, value_int);
				net_reply(net_reply_str);
			}
			break;

		case CMD_WAIT:
			rgota_delay(value_int*1000);
			strcpy(net_reply_str, "OK ");
			get_cmd_string(net_reply_str+3, cmd_int, value_int);
			net_reply(net_reply_str);
			break;
	}

	//Serial.printf("exec_command() returns %d\n", retval_int);
	return retval_int;
}

// return the 3 chars command string corresponding to cmd_int and value_int
char *get_cmd_string(char *buffer_str, Command cmd_int, int value_int) {
	buffer_str[0]=CMD_LETTERS[cmd_int];
	sprintf(buffer_str+1, "%02d", value_int);
	buffer_str[3]='\0';
	return buffer_str;
}
