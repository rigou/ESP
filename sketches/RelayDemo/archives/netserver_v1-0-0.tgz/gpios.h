/* gpios.h - Hadware configuration
 *	ESP32 recommended gpios: /home/rigou/ELECTRONIQUE/Micro controleurs/ESP32/ESP32 recommended GPIOs.txt
*/

#ifndef gpios_h
#define gpios_h

// ESP-WROOM-32E Development Board
#define RUNLED_GPIO 2		// this activity led provides a visual feedback of the loop() function, see set_run_led()
#define RUNLED_INVERTED 0	// 0=normal, 1=inverted (on some boards the built-in led logic is inverted)

// ESP32-DOWDQ6 Wemos Lolin32 Lite
//#define RUNLED_GPIO 22		// this activity led provides a visual feedback of the loop() function, see set_run_led()
//#define RUNLED_INVERTED 1	// 0=normal, 1=inverted (on some boards the built-in led logic is inverted)

// these 3 pins select the device identifier, see net_device_id()
#ifdef USE_HW_DEVICE_ID
#define DEVBIT0_GPIO 13 //gpio of bit0
#define DEVBIT1_GPIO 14 //gpio of bit1
#define DEVBIT2_GPIO 27 //gpio of bit2
#endif

#endif
