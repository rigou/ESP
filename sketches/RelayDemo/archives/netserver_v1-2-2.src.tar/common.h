#pragma once

#define NETSERVER_NAME	"NetServer" // spaces not permitted
#define NETSERVER_VERSION "v1.2.2"

// uncomment next line to enable function calls tracing when debugging this app
//#define RGNET_TRACE
#ifdef RGNET_TRACE
#define rgTrace(x) 	{ Serial.print("  "); Serial.print(x); Serial.println("()"); }
#else
#define rgTrace(x)
#endif

// if USE_HW_DEVICE_ID is defined below then gpios DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO define the device id, see net_device_id()
// else the device id = 0 and DEVBIT0_GPIO, DEVBIT1_GPIO, DEVBIT2_GPIO are ignored
//#define USE_HW_DEVICE_ID 1

// structure instantiated in NetServer.ino
struct Feature_struct {
	short Runled_enabled_int=0; // disabled by default, enable RUNLED with command F01
#ifdef RGWIFI_OTA_ENABLED // constant defined in rgWiFi.h
    short Ota_enabled_int=1;
#else
    short Ota_enabled_int=0;
#endif    
};

char *com_Uptime(char *buffer_str);
void com_Heartbeat(int count_int);
void com_RunLed(bool state_bool);

// Add your own definitions here
#define APP_NAME	"RelayBoard" // spaces not permitted
#define APP_VERSION "v1.0.0"
#define MY_RELAY_GPIO  2
#define OpenRelay(x) digitalWrite(x, HIGH)
#define CloseRelay(x) digitalWrite(x, LOW)
