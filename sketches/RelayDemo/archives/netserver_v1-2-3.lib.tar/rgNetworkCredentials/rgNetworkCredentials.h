#pragma once

#define SSID_NET1       "SFR_A0B0"
#define PASSWD_NET1     "10A05B1955+18A01B1967"
#define SUBNET_NET1		(IPAddress(255, 255, 255, 0))
#define GATEWAY_NET1	(IPAddress(192, 168, 1, 1))

#define SSID_NET2       "ITFR24"
#define PASSWD_NET2     "owbpg84160"
#define SUBNET_NET2		(IPAddress(255, 255, 255, 0))
#define GATEWAY_NET2	(IPAddress(192, 168, 2, 1))

// default credentials for OTA WiFi connection
#define OTA_SSID        SSID_NET2
#define OTA_PASSWORD    PASSWD_NET2

// md5 hash of the password used for securing uploads with espota.py
// $ echo -n "OTA0314" |md5sum  outputs "0b11c2dc837f67c2c81877ec357f595d"
#define ESPOTA_PASSWORD_HASH    "0b11c2dc837f67c2c81877ec357f595d"
